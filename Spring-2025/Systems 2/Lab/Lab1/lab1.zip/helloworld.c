#include <stdio.h>

int main(void) {

	printf("Hello. My name is Gage.\n");
	printf("I am taking SP25-CSE2431 about Operating Systems.\n");

	return 0;
}
